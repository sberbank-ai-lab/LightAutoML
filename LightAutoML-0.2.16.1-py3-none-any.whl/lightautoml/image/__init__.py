"""Provides an internal interface for working with image features."""

__all__ = ['image']
