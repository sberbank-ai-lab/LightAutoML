.. role:: raw-html(raw)
   :format: html

.. |br| raw:: html

   <br />
