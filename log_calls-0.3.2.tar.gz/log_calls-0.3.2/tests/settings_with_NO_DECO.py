__author__ = 'brianoneill'

g_DECORATE = False

#-----------------------------------------------------------------------------
g_settings_dict = {
    'NO_DECO': not g_DECORATE,
    'indent': True,
    'log_retval': True
}
